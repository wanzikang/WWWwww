import {
  isCustomerServicePluginMessage,
  isMessageInvisible as isCustomServiceMessageInvisible,
} from '../../../tui-customer-service-plugin';
export { isCustomerServicePluginMessage, isCustomServiceMessageInvisible };
