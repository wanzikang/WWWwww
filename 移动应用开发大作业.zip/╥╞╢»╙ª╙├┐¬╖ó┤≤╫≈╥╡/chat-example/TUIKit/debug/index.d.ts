export function genTestUserSig({ SDKAppID: number, secretKey: string, userID: string }): any;
export const EXPIRETIME: number;
