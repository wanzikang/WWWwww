import { default as Emoji } from '../../components/TUIChat/emoji-config/locales/en';
export default Emoji;
