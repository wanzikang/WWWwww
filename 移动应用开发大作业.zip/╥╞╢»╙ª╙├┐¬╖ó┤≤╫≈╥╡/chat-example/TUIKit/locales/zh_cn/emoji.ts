import { default as Emoji } from '../../components/TUIChat/emoji-config/locales/zh_cn';
export default Emoji;
