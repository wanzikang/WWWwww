import TUIContact from './index.vue';
import Server from './server';
Server.getInstance();

export default TUIContact;
