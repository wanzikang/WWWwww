import SelectFriend from './index.vue';

export default SelectFriend;
