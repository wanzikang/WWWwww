import ContactList from './index.vue';

export default ContactList;
