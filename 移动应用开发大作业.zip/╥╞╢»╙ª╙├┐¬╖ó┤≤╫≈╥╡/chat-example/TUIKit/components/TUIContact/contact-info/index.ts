import ContactInfo from './index.vue';

export default ContactInfo;
