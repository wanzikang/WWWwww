import ImagePreviewer from './index.vue';

export default ImagePreviewer;
