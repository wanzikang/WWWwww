import Transfer from './index.vue';
export default Transfer;
