const TOAST_TYPE = {
  SUCCESS: 'success',
  WARNING: 'warning',
  ERROR: 'error',
  NORMAL: 'normal',
};

export default TOAST_TYPE;
