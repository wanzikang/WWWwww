import Loading from './index.vue';
export default Loading;
