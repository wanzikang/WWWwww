import BottomPopup from './index.vue';

export default BottomPopup;
