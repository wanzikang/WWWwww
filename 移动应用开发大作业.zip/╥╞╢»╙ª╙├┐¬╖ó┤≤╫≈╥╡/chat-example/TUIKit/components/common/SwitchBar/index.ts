import SwitchBar from './index.vue';
export default SwitchBar;
