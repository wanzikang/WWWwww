import { TUIChatKit } from '../../index.ts';
TUIChatKit?.init(); // Add optional chaining operator to fix sample main package integration errors
