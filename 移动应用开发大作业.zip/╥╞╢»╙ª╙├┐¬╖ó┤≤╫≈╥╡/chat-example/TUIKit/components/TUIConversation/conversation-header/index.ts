import ConversationHeader from './index.vue';

export default ConversationHeader;
