import ConversationNetwork from './index.vue';

export default ConversationNetwork;
