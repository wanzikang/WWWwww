import TUIConversation from "./index.vue";
import TUIConversationServer from "./server";
new TUIConversationServer();

export default TUIConversation;
