import CreateGroup from './index.vue';

export default CreateGroup;
