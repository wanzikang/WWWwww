import TUIGroup from './index.vue';
import Server from './server';

Server.getInstance();

export default TUIGroup;
