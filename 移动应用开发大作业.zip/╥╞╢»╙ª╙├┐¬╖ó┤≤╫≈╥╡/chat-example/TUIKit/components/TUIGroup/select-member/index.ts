import SelectMember from './index.vue';

export default SelectMember;
