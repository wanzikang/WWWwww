import ManageGroup from './index.vue';

export default ManageGroup;
