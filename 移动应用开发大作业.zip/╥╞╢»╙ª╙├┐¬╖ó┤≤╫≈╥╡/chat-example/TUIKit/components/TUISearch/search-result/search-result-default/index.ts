import SearchResultDefault from './index.vue';
export default SearchResultDefault;
