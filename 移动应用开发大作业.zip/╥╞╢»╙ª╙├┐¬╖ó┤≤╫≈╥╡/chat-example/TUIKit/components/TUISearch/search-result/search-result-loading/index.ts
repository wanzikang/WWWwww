import SearchResultLoading from './index.vue';
export default SearchResultLoading;
