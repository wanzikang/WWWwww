import SearchResult from './index.vue';
export default SearchResult;
