import SearchMore from './index.vue';

export default SearchMore;
