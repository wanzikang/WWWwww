import SearchInput from './index.vue';
export default SearchInput;
