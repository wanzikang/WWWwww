import TUIChat from './index.vue';
import Server from './server';

new Server();

export default TUIChat;
