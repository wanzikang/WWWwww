import MessageInput from './index.vue';
export default MessageInput;
