import Words from "./index.vue";
export default Words;
