import Evaluate from './index.vue';
export default Evaluate;
