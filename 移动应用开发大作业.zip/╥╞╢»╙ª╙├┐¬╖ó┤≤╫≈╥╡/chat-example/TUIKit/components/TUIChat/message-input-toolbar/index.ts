import MessageInputToolbar from './index.vue';
export default MessageInputToolbar;
