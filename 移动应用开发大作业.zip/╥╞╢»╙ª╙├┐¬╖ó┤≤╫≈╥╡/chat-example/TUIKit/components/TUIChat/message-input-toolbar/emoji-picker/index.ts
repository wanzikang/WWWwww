import EmojiPicker from './index.vue';
export default EmojiPicker;
